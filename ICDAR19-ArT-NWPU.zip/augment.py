import numpy as np
import os
import cv2
import copy
from imgaug import augmenters as iaa
import numpy as np
import imgaug as ia
import random


gtfile = 'dataset_321/dataset_train/IC15_WordRecognition/IC15_gt.txt'
imagedir = 'dataset_321/dataset_train/IC15_WordRecognition/'


f1 = open(gtfile,'r')
data = f1.readlines()
for line in data:
    line = line.split(', ')
    imglabel = line[1]
    s = line[0].split('/')
    cudir = s[0]
    imgname = s[1]
    imgpath = imagedir + imgname
    img = cv2.imread(imgpath)
    t = imgname.split('.')
    imgname = t[0]
        

    # seq = iaa.Sequential(
    # [
    #     iaa.OneOf([
    #                 iaa.GaussianBlur((0, 3.0)),
    #                 iaa.AverageBlur(k=(2, 7)),
    #                 iaa.MedianBlur(k=(3, 11)),
    #             ])
    #     ])

    # outimg = seq.augment_images(img)
    # outimgname = imgname + '_gs.jpg'
    # outpath = imagedir + outimgname
    # cv2.imwrite(outpath,outimg)
    # with open(gtfile,'a') as f:
    #     k = cudir + '/' + outimgname +', ' + imglabel
    #     f.write(k)


    rows,cols,chans = img.shape
    # pts1 = np.float32([[0, 0], [cols - 2, 0], [0, rows - 2]])
    # pts2 = np.float32([[cols * 0.2, rows * 0.1], [cols * 0.9, rows * 0.2], [cols * 0.1, rows * 0.9]])
     
    # M = cv2.getAffineTransform(pts1, pts2)
    # outimg = cv2.warpAffine(img, M, (cols, rows))
    # outimgname = imgname + '_fsbh.jpg'
    # outpath = imagedir + outimgname
    # cv2.imwrite(outpath,outimg)
    # with open(gtfile,'a') as f:
    #     k = cudir + '/' + outimgname +', ' + imglabel
    #     f.write(k)


    
    angle = random.randint(-40,0)
    M = cv2.getRotationMatrix2D((cols/2,rows/2),angle,0.6)
    outimg = cv2.warpAffine(img,M,(cols+20,rows+20))
    outimgname = imgname + '_xz1.jpg'
    outpath = imagedir + outimgname
    cv2.imwrite(outpath,outimg)
    with open(gtfile,'a') as f:
        k = cudir + '/' + outimgname +', ' + imglabel
        f.write(k)


    angle = random.randint(0,40)
    M = cv2.getRotationMatrix2D((cols/2,rows/2),angle,0.6)
    outimg = cv2.warpAffine(img,M,(cols+20,rows+20))
    outimgname = imgname + '_xz2.jpg'
    outpath = imagedir + outimgname
    cv2.imwrite(outpath,outimg)
    with open(gtfile,'a') as f:
        k = cudir + '/' + outimgname +', ' + imglabel
        f.write(k)