import lmdb

env_db = lmdb.Environment('./DataDB_321/train_aug')

txn = env_db.begin()

for key, value in txn.cursor():  
    print (key, value)  
  
env_db.close() 